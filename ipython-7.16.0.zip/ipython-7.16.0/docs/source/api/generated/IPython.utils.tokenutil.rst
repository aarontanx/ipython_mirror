.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.tokenutil`
==============================
.. automodule:: IPython.utils.tokenutil

.. currentmodule:: IPython.utils.tokenutil

3 Functions
-----------

.. autofunction:: IPython.utils.tokenutil.generate_tokens


.. autofunction:: IPython.utils.tokenutil.line_at_cursor


.. autofunction:: IPython.utils.tokenutil.token_at_cursor

