.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.encoding`
=============================
.. automodule:: IPython.utils.encoding

.. currentmodule:: IPython.utils.encoding

2 Functions
-----------

.. autofunction:: IPython.utils.encoding.get_stream_enc


.. autofunction:: IPython.utils.encoding.getdefaultencoding

