.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.demo`
=======================
.. automodule:: IPython.lib.demo

.. currentmodule:: IPython.lib.demo

8 Classes
---------

.. autoclass:: DemoError
  :members:
  :show-inheritance:

.. autoclass:: Demo
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: IPythonDemo
  :members:
  :show-inheritance:

.. autoclass:: LineDemo
  :members:
  :show-inheritance:

.. autoclass:: IPythonLineDemo
  :members:
  :show-inheritance:

.. autoclass:: ClearMixin
  :members:
  :show-inheritance:

.. autoclass:: ClearDemo
  :members:
  :show-inheritance:

.. autoclass:: ClearIPDemo
  :members:
  :show-inheritance:

2 Functions
-----------

.. autofunction:: IPython.lib.demo.re_mark


.. autofunction:: IPython.lib.demo.slide

