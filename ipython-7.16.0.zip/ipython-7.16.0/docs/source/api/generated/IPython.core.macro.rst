.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.macro`
=========================
.. automodule:: IPython.core.macro

.. currentmodule:: IPython.core.macro

1 Class
-------

.. autoclass:: Macro
  :members:
  :show-inheritance:

  .. automethod:: __init__
