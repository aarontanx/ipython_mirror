.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.contexts`
=============================
.. automodule:: IPython.utils.contexts

.. currentmodule:: IPython.utils.contexts

2 Classes
---------

.. autoclass:: preserve_keys
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: NoOpContext
  :members:
  :show-inheritance:

  .. automethod:: __init__
