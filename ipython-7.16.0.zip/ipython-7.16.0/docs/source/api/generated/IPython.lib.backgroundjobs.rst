.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.backgroundjobs`
=================================
.. automodule:: IPython.lib.backgroundjobs

.. currentmodule:: IPython.lib.backgroundjobs

4 Classes
---------

.. autoclass:: BackgroundJobManager
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: BackgroundJobBase
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: BackgroundJobExpr
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: BackgroundJobFunc
  :members:
  :show-inheritance:

  .. automethod:: __init__
