.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.payload`
===========================
.. automodule:: IPython.core.payload

.. currentmodule:: IPython.core.payload

1 Class
-------

.. autoclass:: PayloadManager
  :members:
  :show-inheritance:
