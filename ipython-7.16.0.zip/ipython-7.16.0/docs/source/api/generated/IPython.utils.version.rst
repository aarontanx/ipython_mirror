.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.version`
============================
.. automodule:: IPython.utils.version

.. currentmodule:: IPython.utils.version

1 Function
----------

.. autofunction:: IPython.utils.version.check_version

