.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.tempdir`
============================
.. automodule:: IPython.utils.tempdir

.. currentmodule:: IPython.utils.tempdir

2 Classes
---------

.. autoclass:: NamedFileInTemporaryDirectory
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: TemporaryWorkingDirectory
  :members:
  :show-inheritance:
