.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.prompts`
===============================
.. automodule:: IPython.terminal.prompts

.. currentmodule:: IPython.terminal.prompts

3 Classes
---------

.. autoclass:: Prompts
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ClassicPrompts
  :members:
  :show-inheritance:

.. autoclass:: RichPromptDisplayHook
  :members:
  :show-inheritance:
