.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.decorators`
=================================
.. automodule:: IPython.testing.decorators

.. currentmodule:: IPython.testing.decorators

11 Functions
------------

.. autofunction:: IPython.testing.decorators.as_unittest


.. autofunction:: IPython.testing.decorators.apply_wrapper


.. autofunction:: IPython.testing.decorators.make_label_dec


.. autofunction:: IPython.testing.decorators.skipif


.. autofunction:: IPython.testing.decorators.skip


.. autofunction:: IPython.testing.decorators.onlyif


.. autofunction:: IPython.testing.decorators.module_not_available


.. autofunction:: IPython.testing.decorators.decorated_dummy


.. autofunction:: IPython.testing.decorators.skip_file_no_x11


.. autofunction:: IPython.testing.decorators.onlyif_cmds_exist


.. autofunction:: IPython.testing.decorators.onlyif_any_cmd_exists

