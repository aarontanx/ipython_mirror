.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.importstring`
=================================
.. automodule:: IPython.utils.importstring

.. currentmodule:: IPython.utils.importstring

1 Function
----------

.. autofunction:: IPython.utils.importstring.import_item

