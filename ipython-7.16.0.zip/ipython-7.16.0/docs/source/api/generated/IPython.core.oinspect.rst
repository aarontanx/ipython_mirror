.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.oinspect`
============================
.. automodule:: IPython.core.oinspect

.. currentmodule:: IPython.core.oinspect

1 Class
-------

.. autoclass:: Inspector
  :members:
  :show-inheritance:

  .. automethod:: __init__

8 Functions
-----------

.. autofunction:: IPython.core.oinspect.pylight


.. autofunction:: IPython.core.oinspect.object_info


.. autofunction:: IPython.core.oinspect.get_encoding


.. autofunction:: IPython.core.oinspect.getdoc


.. autofunction:: IPython.core.oinspect.getsource


.. autofunction:: IPython.core.oinspect.is_simple_callable


.. autofunction:: IPython.core.oinspect.find_file


.. autofunction:: IPython.core.oinspect.find_source_lines

