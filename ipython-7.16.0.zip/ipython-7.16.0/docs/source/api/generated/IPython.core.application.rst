.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.application`
===============================
.. automodule:: IPython.core.application

.. currentmodule:: IPython.core.application

2 Classes
---------

.. autoclass:: ProfileAwareConfigLoader
  :members:
  :show-inheritance:

.. autoclass:: BaseIPythonApplication
  :members:
  :show-inheritance:

  .. automethod:: __init__
