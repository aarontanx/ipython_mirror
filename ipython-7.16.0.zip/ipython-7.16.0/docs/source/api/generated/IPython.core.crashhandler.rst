.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.crashhandler`
================================
.. automodule:: IPython.core.crashhandler

.. currentmodule:: IPython.core.crashhandler

1 Class
-------

.. autoclass:: CrashHandler
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.core.crashhandler.crash_handler_lite

