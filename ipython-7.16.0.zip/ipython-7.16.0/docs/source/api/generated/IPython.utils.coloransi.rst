.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.coloransi`
==============================
.. automodule:: IPython.utils.coloransi

.. currentmodule:: IPython.utils.coloransi

5 Classes
---------

.. autoclass:: TermColors
  :members:
  :show-inheritance:

.. autoclass:: InputTermColors
  :members:
  :show-inheritance:

.. autoclass:: NoColors
  :members:
  :show-inheritance:

.. autoclass:: ColorScheme
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ColorSchemeTable
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.utils.coloransi.make_color_table

