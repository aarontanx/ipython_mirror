.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.capture`
============================
.. automodule:: IPython.utils.capture

.. currentmodule:: IPython.utils.capture

3 Classes
---------

.. autoclass:: RichOutput
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: CapturedIO
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: capture_output
  :members:
  :show-inheritance:

  .. automethod:: __init__
