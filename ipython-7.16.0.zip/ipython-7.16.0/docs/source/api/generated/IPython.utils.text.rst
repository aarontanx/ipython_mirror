.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.text`
=========================
.. automodule:: IPython.utils.text

.. currentmodule:: IPython.utils.text

5 Classes
---------

.. autoclass:: LSString
  :members:
  :show-inheritance:

.. autoclass:: SList
  :members:
  :show-inheritance:

.. autoclass:: EvalFormatter
  :members:
  :show-inheritance:

.. autoclass:: FullEvalFormatter
  :members:
  :show-inheritance:

.. autoclass:: DollarFormatter
  :members:
  :show-inheritance:

13 Functions
------------

.. autofunction:: IPython.utils.text.indent


.. autofunction:: IPython.utils.text.list_strings


.. autofunction:: IPython.utils.text.marquee


.. autofunction:: IPython.utils.text.num_ini_spaces


.. autofunction:: IPython.utils.text.format_screen


.. autofunction:: IPython.utils.text.dedent


.. autofunction:: IPython.utils.text.wrap_paragraphs


.. autofunction:: IPython.utils.text.long_substr


.. autofunction:: IPython.utils.text.strip_email_quotes


.. autofunction:: IPython.utils.text.strip_ansi


.. autofunction:: IPython.utils.text.compute_item_matrix


.. autofunction:: IPython.utils.text.columnize


.. autofunction:: IPython.utils.text.get_text_list

