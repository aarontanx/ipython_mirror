.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.magic_arguments`
===================================
.. automodule:: IPython.core.magic_arguments

.. currentmodule:: IPython.core.magic_arguments

8 Classes
---------

.. autoclass:: MagicArgumentParser
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ArgDecorator
  :members:
  :show-inheritance:

.. autoclass:: magic_arguments
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ArgMethodWrapper
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: argument
  :members:
  :show-inheritance:

.. autoclass:: defaults
  :members:
  :show-inheritance:

.. autoclass:: argument_group
  :members:
  :show-inheritance:

.. autoclass:: kwds
  :members:
  :show-inheritance:

  .. automethod:: __init__

3 Functions
-----------

.. autofunction:: IPython.core.magic_arguments.construct_parser


.. autofunction:: IPython.core.magic_arguments.parse_argstring


.. autofunction:: IPython.core.magic_arguments.real_name

