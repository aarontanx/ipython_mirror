:orphan:

.. _parallel_index:

====================================
Using IPython for parallel computing
====================================

IPython.parallel has moved to `ipyparallel <https://github.com/ipython/ipyparallel>`_.
