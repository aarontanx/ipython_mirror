Antigravity feature
===================

Example new antigravity feature. Try ``import antigravity`` in a Python 3
console.
