
from warnings import warn

warn("IPython.utils.log has moved to traitlets.log", stacklevel=2)

from traitlets.log import *
