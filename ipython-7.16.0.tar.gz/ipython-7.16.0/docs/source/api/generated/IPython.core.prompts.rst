.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.prompts`
===========================
.. automodule:: IPython.core.prompts

.. currentmodule:: IPython.core.prompts

1 Class
-------

.. autoclass:: LazyEvaluate
  :members:
  :show-inheritance:

  .. automethod:: __init__
