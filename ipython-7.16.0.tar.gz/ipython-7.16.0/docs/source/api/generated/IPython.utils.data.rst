.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.data`
=========================
.. automodule:: IPython.utils.data

.. currentmodule:: IPython.utils.data

2 Functions
-----------

.. autofunction:: IPython.utils.data.uniq_stable


.. autofunction:: IPython.utils.data.chop

