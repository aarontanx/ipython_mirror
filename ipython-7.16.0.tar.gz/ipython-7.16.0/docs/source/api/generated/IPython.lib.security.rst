.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.security`
===========================
.. automodule:: IPython.lib.security

.. currentmodule:: IPython.lib.security

2 Functions
-----------

.. autofunction:: IPython.lib.security.passwd


.. autofunction:: IPython.lib.security.passwd_check

