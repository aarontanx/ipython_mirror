.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.historyapp`
==============================
.. automodule:: IPython.core.historyapp

.. currentmodule:: IPython.core.historyapp

3 Classes
---------

.. autoclass:: HistoryTrim
  :members:
  :show-inheritance:

.. autoclass:: HistoryClear
  :members:
  :show-inheritance:

.. autoclass:: HistoryApp
  :members:
  :show-inheritance:
