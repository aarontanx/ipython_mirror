.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.shortcuts`
=================================
.. automodule:: IPython.terminal.shortcuts

.. currentmodule:: IPython.terminal.shortcuts

13 Functions
------------

.. autofunction:: IPython.terminal.shortcuts.create_ipython_shortcuts


.. autofunction:: IPython.terminal.shortcuts.reformat_text_before_cursor


.. autofunction:: IPython.terminal.shortcuts.newline_or_execute_outer


.. autofunction:: IPython.terminal.shortcuts.previous_history_or_previous_completion


.. autofunction:: IPython.terminal.shortcuts.next_history_or_next_completion


.. autofunction:: IPython.terminal.shortcuts.dismiss_completion


.. autofunction:: IPython.terminal.shortcuts.reset_buffer


.. autofunction:: IPython.terminal.shortcuts.reset_search_buffer


.. autofunction:: IPython.terminal.shortcuts.suspend_to_bg


.. autofunction:: IPython.terminal.shortcuts.force_exit


.. autofunction:: IPython.terminal.shortcuts.indent_buffer


.. autofunction:: IPython.terminal.shortcuts.newline_autoindent_outer


.. autofunction:: IPython.terminal.shortcuts.open_input_in_editor

