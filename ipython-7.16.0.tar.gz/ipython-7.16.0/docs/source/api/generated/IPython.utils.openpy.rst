.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.openpy`
===========================
.. automodule:: IPython.utils.openpy

.. currentmodule:: IPython.utils.openpy

4 Functions
-----------

.. autofunction:: IPython.utils.openpy.source_to_unicode


.. autofunction:: IPython.utils.openpy.strip_encoding_cookie


.. autofunction:: IPython.utils.openpy.read_py_file


.. autofunction:: IPython.utils.openpy.read_py_url

