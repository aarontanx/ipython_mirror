.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.tz`
=======================
.. automodule:: IPython.utils.tz

.. currentmodule:: IPython.utils.tz

1 Class
-------

.. autoclass:: tzUTC
  :members:
  :show-inheritance:

1 Function
----------

.. autofunction:: IPython.utils.tz.utc_aware

