.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.shimmodule`
===============================
.. automodule:: IPython.utils.shimmodule

.. currentmodule:: IPython.utils.shimmodule

3 Classes
---------

.. autoclass:: ShimWarning
  :members:
  :show-inheritance:

.. autoclass:: ShimImporter
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ShimModule
  :members:
  :show-inheritance:

  .. automethod:: __init__
