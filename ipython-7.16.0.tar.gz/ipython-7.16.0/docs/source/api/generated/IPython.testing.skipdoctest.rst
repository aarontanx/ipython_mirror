.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.skipdoctest`
==================================
.. automodule:: IPython.testing.skipdoctest

.. currentmodule:: IPython.testing.skipdoctest

1 Function
----------

.. autofunction:: IPython.testing.skipdoctest.skip_doctest

