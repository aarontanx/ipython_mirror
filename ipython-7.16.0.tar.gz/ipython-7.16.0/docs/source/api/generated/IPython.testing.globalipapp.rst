.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.globalipapp`
==================================
.. automodule:: IPython.testing.globalipapp

.. currentmodule:: IPython.testing.globalipapp

1 Class
-------

.. autoclass:: StreamProxy
  :members:
  :show-inheritance:

  .. automethod:: __init__

3 Functions
-----------

.. autofunction:: IPython.testing.globalipapp.get_ipython


.. autofunction:: IPython.testing.globalipapp.xsys


.. autofunction:: IPython.testing.globalipapp.start_ipython

