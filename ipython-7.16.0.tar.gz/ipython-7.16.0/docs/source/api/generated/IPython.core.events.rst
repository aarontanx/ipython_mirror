.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.events`
==========================
.. automodule:: IPython.core.events

.. currentmodule:: IPython.core.events

1 Class
-------

.. autoclass:: EventManager
  :members:
  :show-inheritance:

  .. automethod:: __init__

5 Functions
-----------

.. autofunction:: IPython.core.events.pre_execute


.. autofunction:: IPython.core.events.pre_run_cell


.. autofunction:: IPython.core.events.post_execute


.. autofunction:: IPython.core.events.post_run_cell


.. autofunction:: IPython.core.events.shell_initialized

