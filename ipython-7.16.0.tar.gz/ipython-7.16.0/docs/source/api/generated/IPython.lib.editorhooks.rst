.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.editorhooks`
==============================
.. automodule:: IPython.lib.editorhooks

.. currentmodule:: IPython.lib.editorhooks

11 Functions
------------

.. autofunction:: IPython.lib.editorhooks.install_editor


.. autofunction:: IPython.lib.editorhooks.komodo


.. autofunction:: IPython.lib.editorhooks.scite


.. autofunction:: IPython.lib.editorhooks.notepadplusplus


.. autofunction:: IPython.lib.editorhooks.jed


.. autofunction:: IPython.lib.editorhooks.idle


.. autofunction:: IPython.lib.editorhooks.mate


.. autofunction:: IPython.lib.editorhooks.emacs


.. autofunction:: IPython.lib.editorhooks.gnuclient


.. autofunction:: IPython.lib.editorhooks.crimson_editor


.. autofunction:: IPython.lib.editorhooks.kate

