.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.decorators`
===============================
.. automodule:: IPython.utils.decorators

.. currentmodule:: IPython.utils.decorators

2 Functions
-----------

.. autofunction:: IPython.utils.decorators.flag_calls


.. autofunction:: IPython.utils.decorators.undoc

