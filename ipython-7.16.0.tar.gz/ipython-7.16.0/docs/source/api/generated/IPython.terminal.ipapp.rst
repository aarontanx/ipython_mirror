.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.ipapp`
=============================
.. automodule:: IPython.terminal.ipapp

.. currentmodule:: IPython.terminal.ipapp

3 Classes
---------

.. autoclass:: IPAppCrashHandler
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: LocateIPythonApp
  :members:
  :show-inheritance:

.. autoclass:: TerminalIPythonApp
  :members:
  :show-inheritance:

1 Function
----------

.. autofunction:: IPython.terminal.ipapp.load_default_config

