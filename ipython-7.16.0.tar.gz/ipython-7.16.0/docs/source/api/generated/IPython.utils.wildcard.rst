.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.wildcard`
=============================
.. automodule:: IPython.utils.wildcard

.. currentmodule:: IPython.utils.wildcard

6 Functions
-----------

.. autofunction:: IPython.utils.wildcard.create_typestr2type_dicts


.. autofunction:: IPython.utils.wildcard.is_type


.. autofunction:: IPython.utils.wildcard.show_hidden


.. autofunction:: IPython.utils.wildcard.dict_dir


.. autofunction:: IPython.utils.wildcard.filter_ns


.. autofunction:: IPython.utils.wildcard.list_namespace

