.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.path`
=========================
.. automodule:: IPython.utils.path

.. currentmodule:: IPython.utils.path

1 Class
-------

.. autoclass:: HomeDirError
  :members:
  :show-inheritance:

16 Functions
------------

.. autofunction:: IPython.utils.path.get_long_path_name


.. autofunction:: IPython.utils.path.unquote_filename


.. autofunction:: IPython.utils.path.compress_user


.. autofunction:: IPython.utils.path.get_py_filename


.. autofunction:: IPython.utils.path.filefind


.. autofunction:: IPython.utils.path.get_home_dir


.. autofunction:: IPython.utils.path.get_xdg_dir


.. autofunction:: IPython.utils.path.get_xdg_cache_dir


.. autofunction:: IPython.utils.path.expand_path


.. autofunction:: IPython.utils.path.unescape_glob


.. autofunction:: IPython.utils.path.shellglob


.. autofunction:: IPython.utils.path.target_outdated


.. autofunction:: IPython.utils.path.target_update


.. autofunction:: IPython.utils.path.link


.. autofunction:: IPython.utils.path.link_or_copy


.. autofunction:: IPython.utils.path.ensure_dir_exists

