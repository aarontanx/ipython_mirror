.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.ulinecache`
===============================
.. automodule:: IPython.utils.ulinecache

.. currentmodule:: IPython.utils.ulinecache

1 Function
----------

.. autofunction:: IPython.utils.ulinecache.getlines

